import React, { useState, useEffect } from "react";
import { Bar,Pie,Radar ,Line,PolarArea } from 'react-chartjs-2';
import 'chart.js/auto'; 
import "../styles/dashboard.css";
import ClipLoader from 'react-spinners/ClipLoader';


async function RoleAccess(client, setHasAccess) {

  let iparamSelectedCategory = client.context.settings.selectedCategory;
  console.log("iparamSelectedCategory", iparamSelectedCategory);

  const contactData = await client.data.get('loggedInUser');
  // console.log("contactData",contactData);
  

  let loggedInEmail = contactData.loggedInUser.contact.id;

  let loggedInGroups = contactData.loggedInUser.group_ids;  
  
  var logginuserID = [];
  for (var i = 0; i < contactData.loggedInUser.role_ids.length; i++) {
    logginuserID.push(contactData.loggedInUser.role_ids[i]);
  }
// console.log("logginuserID",logginuserID);

  // Convert loggedInEmail to string
  let loggedInEmailStr = loggedInEmail.toString().trim();
  iparamSelectedCategory = iparamSelectedCategory.map(value => value.trim());

  const roleMatch = iparamSelectedCategory.some(role => logginuserID.toString().includes(role.toString()));
  console.log("roleMatch", roleMatch);

  const emailMatch = iparamSelectedCategory.includes(loggedInEmailStr);
  console.log("emailMatch", emailMatch);

  const groupMatch = loggedInGroups.some(group => iparamSelectedCategory.includes(group.toString()));
  console.log("groupMatch", groupMatch);

  // const loggedInWorkspaces = logginuser.agent.workspace_ids || [];
  // console.log("loggedInWorkspaces",loggedInWorkspaces);
  
  // const selectedWorkspaces = client.context.settings.getUseWorkspace.map(ws => ws.id);
  // console.log("selectd ",selectedWorkspaces);
  // const workspaceMatch = loggedInWorkspaces.some(ws => selectedWorkspaces.includes(ws));
  // console.log("workspaceMatch", workspaceMatch);

  const hasAccess =  (roleMatch || emailMatch || groupMatch);
  setHasAccess(hasAccess);

  console.log("hasAccess", hasAccess);
}

const fetchingRecords = async (client,  
                              setTicketsByMonth, 
                              setDuplicateByMonth, 
                              setTopDuplicateWorkItems, 
                              setunresolvedWIByMonth, 
                              setTicketAgingByCategory, 
                              setWorkItemAgingByCategory) => {
                  // console.log("Inside of fetchingRecords function");

                  try {
                    const entity = client.db.entity({ version: "v1" });
                    const transticEntity = entity.get("AzureWorkItem");
                    let nextMarker = null;
                    let recordsArray = [];

    // Loop until there are no more pages
                while (true) {
                const allRecords = await transticEntity.getAll({
                  query: { status: "Active" },
                  ...(nextMarker ? { next: { marker: nextMarker } } : {})
                                   });

      if (allRecords.records && Array.isArray(allRecords.records)) {
        recordsArray = [...recordsArray, ...allRecords.records]; 
      }

      nextMarker = allRecords.next ? allRecords.next.marker : null;

      if (!nextMarker) break; 
    }

    console.log("Total records fetched:", recordsArray.length);
                    console.log("allRecords:", recordsArray);
                    // const recordsArray = allRecords && Array.isArray(allRecords.records) ? allRecords.records : [];

                       // ticket created at month and year
                       const ticketsByMonth = {};
                       recordsArray.forEach(record => {
                         const month = new Date(record.data.ticket_created_at).toLocaleString('default', { year: 'numeric', month: 'long' }); //ex:October 2024
                         if (!ticketsByMonth[month]) {
                           ticketsByMonth[month] = { count: 0, tickets: new Set() };
                         }
                        //counts of the ticket 
                         const ticketId = record.data.ticket_id;
                         if (!ticketsByMonth[month].tickets.has(ticketId)) {
                           ticketsByMonth[month].count++;
                           ticketsByMonth[month].tickets.add(ticketId);
                         }
                       });
                       
                       // To get the count directly in `ticketsByMonth`
                       Object.keys(ticketsByMonth).forEach(month => {
                         ticketsByMonth[month] = ticketsByMonth[month].count;
                       });
                       
                      //  console.log("Tickets By Month Calculated:", ticketsByMonth);//Octobar2024:3

                    const workItemMap = recordsArray.reduce((acc, record) => {
                      const workItemId = record.data.workItem_id;
                      if (!acc[workItemId]) {
                        acc[workItemId] = [];
                      }
                      acc[workItemId].push(record);
                      return acc;
                    }, {});
                    // console.log("Work Item Map:", workItemMap);

                    // Identify duplicate work items
                    const duplicateWorkItems = Object.entries(workItemMap)
                      .filter(([workItemId, records]) => records.length > 1)
                      .map(([workItemId, records]) => ({
                        workItemId,
                        count: records.length
                      }));

                    const top10WorkItems = duplicateWorkItems
                      .sort((a, b) => b.count - a.count)
                      .slice(0, 10);

                    const duplicateByMonth = {};

                // Iterate through top 10 work items
                duplicateWorkItems.forEach(({ workItemId }) => {
                  workItemMap[workItemId].forEach(record => {
                    const month = new Date(record.data.created_at).toLocaleString('default', { year: 'numeric', month: 'long' });

                    // Initialize the month in duplicateByMonth if it doesn't exist
                    if (!duplicateByMonth[month]) {
                      duplicateByMonth[month] = new Set(); 
                    }

                    duplicateByMonth[month].add(workItemId);
                  });
                });

                // Convert the Set counts to numbers
                for (const month in duplicateByMonth) {
                  duplicateByMonth[month] = duplicateByMonth[month].size; 
                }                    

                const resolvedStatuses = ['Completed'];

                // Function to remove duplicates based on workitem_id
                const removeDuplicates = (records) => {
                  const uniqueRecords = new Map();
                  records.forEach(record => {
                    const workItemId = record.data.workItem_id; // Assuming 'workitem_id' is the unique identifier
                    if (!uniqueRecords.has(workItemId)) {
                      uniqueRecords.set(workItemId, record);
                    }
                  });
                  return Array.from(uniqueRecords.values());
                };
                
                const unresolvedWorkItems = recordsArray.filter(record => 
                  !resolvedStatuses.includes(record.data.workitem_category) || record.data.workitem_category == null
                );
                
                
                // Remove duplicates from unresolvedWorkItems
                const uniqueUnresolvedWorkItems = removeDuplicates(unresolvedWorkItems);
              //  console.log("uniqueUnresolvedWorkItems",uniqueUnresolvedWorkItems);
               
                
                const unresolvedTickets = recordsArray.filter(record => 
                  record.data.ticket_status !== "5" // Exclude records with ticket_status of "5"
                );
                
                // console.log("Unresolved Tickets:", unresolvedTickets);
                
                // Aggregate unresolved work items by month
                const unresolvedWIByMonth = {};
                uniqueUnresolvedWorkItems.forEach(record => {
                  const month = new Date(record.data.created_at).toLocaleString('default', { year: 'numeric', month: 'long' });
                  if (!unresolvedWIByMonth[month]) {
                    unresolvedWIByMonth[month] = 0;
                  }
                  unresolvedWIByMonth[month]++;
                });                

                    // Calculate Ticket Aging and Work Item Aging
                    const currentDate = new Date();
                    const ticketAgingByCategory = {
                      lessThan2Days: 0,
                     between3And5Days: 0,
                      between5And10Days: 0,
                    }; 
                    const workItemAgingByCategory = {
                      lessThan5Days: 0,
                      between5And10Days: 0,
                      between10And15Days: 0,
                      between15And20Days: 0,
                      moreThan20Days: 0
                    };

                    unresolvedWorkItems.forEach(record => {
                      const workItemCreatedAt = new Date(record.data.created_at);
                      
                      const workItemAging = Math.floor((currentDate - workItemCreatedAt) / (1000 * 60 * 60 * 24));

                      // Categorize Work Item Aging
                      if (workItemAging < 5) {
                        workItemAgingByCategory.lessThan5Days++;
                      } else if (workItemAging >= 5 && workItemAging <= 10) {
                        workItemAgingByCategory.between5And10Days++;
                      } else if (workItemAging > 10 && workItemAging <= 15) {
                        workItemAgingByCategory.between10And15Days++;
                      } else if (workItemAging > 15 && workItemAging <= 20) {
                        workItemAgingByCategory.between15And20Days++;
                      } else {
                        workItemAgingByCategory.moreThan20Days++;
                      }
                    });
                    unresolvedTickets.forEach(record => {
                      const ticketCreatedAt = new Date(record.data.ticket_created_at);
                      const workItemCreatedAt = new Date(record.data.created_at);
                      const ticketAging = Math.floor((workItemCreatedAt - ticketCreatedAt) / (1000 * 60 * 60 * 24));
                    
                      // Categorize Ticket Aging
                      if (ticketAging < 2) {
                        ticketAgingByCategory.lessThan2Days++;
                      } else if (ticketAging >= 2 && ticketAging <= 5) {
                        ticketAgingByCategory.between3And5Days++;
                      } else if (ticketAging > 5 && ticketAging <= 10) {
                        ticketAgingByCategory.between5And10Days++;
                      } else {
                        ticketAgingByCategory.moreThan10Days++;
                      }
                    });
                    // console.log("Ticket  AgingCategory:", ticketAgingByCategory);
                    
                    // Update the state with calculated values
                    setTicketsByMonth(ticketsByMonth);
                    setDuplicateByMonth(duplicateByMonth);
                    setTopDuplicateWorkItems(top10WorkItems);
                    setunresolvedWIByMonth(unresolvedWIByMonth);
                    setTicketAgingByCategory(ticketAgingByCategory);
                    setWorkItemAgingByCategory(workItemAgingByCategory);
                  } catch (error) {
                    console.error("Error retrieving or filtering records:", error);
                  }
                };


export const Dashboard = () => {
  // console.log("client in dashboard", client);
 
  const [activeTab, setActiveTab] = useState('Summary');
  const [ticketsByMonth, setTicketsByMonth] = useState({});
  const [duplicateByMonth, setduplicateByMonth] = useState({});
  const [hasAccess, setHasAccess] = useState(null); 
  const [topDuplicateWorkItems, setTopDuplicateWorkItems] = useState([]);
  const [unresolvedWIByMonth, setunresolvedWIByMonth] = useState([]);
  const [TicketAgingByCategory, setTicketAgingByCategory] = useState({
    lessThan2Days: 0,
    between3And5Days: 0,
    between5And10Days: 0
  });
  const [WorkItemAgingByCategory, setWorkItemAgingByCategory] = useState({
    lessThan5Days: 0,
    between5And10Days: 0,
    between10And15Days: 0,
    between15And20Days: 0,
    moreThan20Days: 0
  });
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    RoleAccess(client, setHasAccess);
  }, [client]);
  useEffect(() => {
    if (hasAccess) {
      setLoading(true);
      fetchingRecords(
        client,
        setTicketsByMonth,
        setduplicateByMonth,
        setTopDuplicateWorkItems,
        setunresolvedWIByMonth,
        setTicketAgingByCategory,
        setWorkItemAgingByCategory
      ).finally(() => {
        setLoading(false);
      });
    }
  }, [hasAccess]);
  const renderChart = (data, ChartComponent, title) => {
    if (loading) {
      return (
        <div className="spinner-container">
          <ClipLoader size={25} color={"#123abc"} loading={loading} />
        </div>
      );
    } else if (!data || data.datasets[0].data.length === 0) {
      return (<div style={noDataStyle}>
        <p>No data available.</p>
      </div>
      )
    } else {
      const options = {
        responsive: true,
        scales: {
          y: {
            ticks: {
              callback: (value) => {
                const intValue = parseInt(value);
                return intValue;
              },
              beginAtZero: true, 
              stepSize: 1,  
            },
          },
        },
        elements: {
          line: {
            borderWidth: 2 
          },
        },
      };
      return <ChartComponent data={data} options={options} />;
    }
  };
  const renderUnresolvedWorkItemsChart = () => {
    if (loading) {
      return (
        <div className="spinner-container">
          <ClipLoader size={25} color={"#123abc"} loading={loading} />
        </div>
      );
    }
    if (unresolvedChartData.datasets[0].data.every(value => value === 0)) {
      return (
        <div style={noDataStyle}>
          <p>No data available.</p>
        </div>
      );
    }
  
    const options = {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: (value) => parseInt(value),
            stepSize: 1,
          },
        },
        x: {
          ticks: {
            autoSkip: false,
          },
        },
      },
      elements: {
        line: {
          tension: 0.4,
          borderWidth: 2,
        },
      },
    };
  
    return <Line data={unresolvedChartData} options={options} />;
  };
  
  const renderAgeChart = () => {
    if (loading) {
      return (
        <div className="spinner-container">
          <ClipLoader size={25} color={"#123abc"} loading={loading} />
        </div>
      );
    }
    if (AgechartData.datasets.every(dataset => dataset.data.every(value => value === 0))) {
      return (
        <div style={noDataStyle}>
          <p>No data available.</p>
        </div>
      );
    }
    const options = {
      responsive: true,
      scales: {
        r: {
          ticks: {
            callback: (value) => parseInt(value),
            beginAtZero: true,
            stepSize: 1,
            font: {
              size: 16, 
              weight: 'bold' 
            }
          }
        }
      },
      elements: {
        line: {
          borderWidth: 2,
          hoverBorderWidth: 3 
        },
        point: {
          radius: 2, 
          hoverRadius: 7 
        }
      },
      plugins: {
        tooltip: {
          mode: 'nearest', 
          intersect: false,
          callbacks: {
            label: (context) => {
              const label = context.dataset.label || '';
              if (label) {
                return `${label}: ${context.raw}`;
              }
              return null;
            }
          },
          filter: (tooltipItem) => tooltipItem.raw > 0 
        }
      }
    };    
  
    return <Radar data={AgechartData} options={options} />;
  };
  
  const renderWorkitemAgeChart = () => {
    if (loading) {
      return (
        <div className="spinner-container">
          <ClipLoader size={25} color={"#123abc"} loading={loading} />
        </div>
      );
    }
    if (WorkitemAgechartData.datasets[0].data.every(value => value === 0)) {
      return (
        <div style={noDataStyle}>
          <p>No data available.</p>
        </div>
      );
    }
  
    const options = {
      responsive: true,
      scales: {
        r: {
          min: 0, 
          ticks: {
            callback: (value) => parseInt(value),
            beginAtZero: true,
            stepSize: 1,
          },
        },
      },
      elements: {
        arc: {
          borderWidth: 2,
        },
      },
    };
  
    return <PolarArea data={WorkitemAgechartData} options={options} />;
  };
  
  const renderTopDuplicateWorkItemsChart = () => {
    if (loading) {
      return (
        <div className="spinner-container">
          <ClipLoader size={25} color={"#123abc"} loading={loading} />
        </div>
      );
    }
    if (topDuplicateWorkItemsData.datasets[0].data.every(value => value === 0)) {
      return (
        <div style={noDataStyle}>
          <p>No data available.</p>
        </div>
      );
    }
  
    return <Pie data={topDuplicateWorkItemsData} options={{ responsive: true }} />;
  };
  
const noDataStyle = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100%', 
  fontSize: '1rem', 
  fontStyle: 'italic', 
  textAlign: 'center', 
  marginTop: '20px',
  fontFamily: 'Arial, sans-serif'
};

  // Transform data for the chart
  const chartData = {
    labels: Object.keys(ticketsByMonth),
    datasets: [
      {
        label: 'Freshdesk to Azure Transferred Tickets',
        data: Object.keys(ticketsByMonth).map(month => ticketsByMonth[month]),
        backgroundColor: 'rgba(132, 230, 106, 0.7)',
        borderColor: 'rgba(27, 128, 1, 1)',
        borderWidth: 1,
      },
    ],
  };
  const DuplicatechartData = {
    labels: Object.keys(duplicateByMonth),
    datasets: [
      {
        label: 'Duplicate Workitem count',
        data: Object.keys(duplicateByMonth).map(month => duplicateByMonth[month]),
        backgroundColor: 'rgba(128, 128, 128, 0.7)',
        borderColor: 'rgba(77, 77, 77, 1)',
        borderWidth: 1,
      },
    ],
  };
  const topDuplicateWorkItemsData = {
    labels: topDuplicateWorkItems.map(item =>`Workitem ID: ${item.workItemId}`),
    datasets: [
      {
        data: topDuplicateWorkItems.map(item => item.count),
        label: 'Tickets connected with above workitem',
        backgroundColor: [
          'rgba(255, 99, 132, 0.7)',
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 206, 86, 0.7)',
          'rgba(75, 192, 192, 0.7)',
          'rgba(153, 102, 255, 0.7)',
          'rgba(255, 159, 64, 0.7)',
          'rgba(199, 199, 199, 0.7)',
          'rgba(83, 102, 255, 0.7)',
          'rgba(255, 159, 223, 0.7)',
          'rgba(99, 255, 132, 0.7)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
          'rgba(199, 199, 199, 1)',
          'rgba(83, 102, 255, 1)',
          'rgba(255, 159, 223, 1)',
          'rgba(99, 255, 132, 1)'
        ],
        borderWidth: 1,
      },
    ],
  };
  const unresolvedChartData = {
    labels: Object.keys(unresolvedWIByMonth),
    datasets: [
      {
        label: 'Unresolved Work Items',
        data: Object.keys(unresolvedWIByMonth).map(month => parseInt(unresolvedWIByMonth[month])), 
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
        fill: true,
      },
    ],
  };
  const AgechartData = {
    labels: ['Less than 2 days', '3-5 days', '5-10 days'],
    datasets: [
      {
        label: 'Less than 2 days',
        data: [
          TicketAgingByCategory.lessThan2Days,
          0, 
          0,
        ],
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1,
      },
      {
        label: '3-5 days',
        data: [
          0,
          TicketAgingByCategory.between3And5Days,
          0, 
        ],
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
      {
        label: '5-10 days',
        data: [
          0,
          0,
          TicketAgingByCategory.between5And10Days,
        ],
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderColor: 'rgba(255, 159, 64, 1)',
        borderWidth: 1,
      },
    ],
  };

  const WorkitemAgechartData = {
    labels: ['Less than 5 days', '5-10 days', '10-15 days', '15-20 days', 'More than 20 days'],
    datasets: [
      {
        label: 'Workitems by Aging',
        data: [
          WorkItemAgingByCategory.lessThan5Days,
          WorkItemAgingByCategory.between5And10Days,
          WorkItemAgingByCategory.between10And15Days,
          WorkItemAgingByCategory.between15And20Days,
          WorkItemAgingByCategory.moreThan20Days,
        ],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
        ],
        borderWidth: 1,
      }
    ],
  };
  return (
    <>
      {hasAccess === null ? (
        <div className="spinner-container">
          <ClipLoader size={40} color={"#123abc"} loading={true} />
        </div>
      ) : hasAccess ? (
        <div className="dashboard">
          <h1 className="dashboard-title">Dashboard</h1>
            <div className="content">
              <div className="nested-tabs">
                {['Summary', 'Status', 'Aging'].map((tab, index) => (
                  <button
                    key={index}
                    className={`nested-tab-button ${activeTab === tab ? 'active' : ''}`}
                    onClick={() => setActiveTab(tab)}
                  >
                    {tab}
                  </button>
                ))}
              </div>
  
              {activeTab === 'Summary' && (
                <div className="chart-container">
                  <div className="pie-container">
                    <h3 className="pie-title">Tickets Transferred</h3>
                    {renderChart(chartData, Bar, 'Tickets Transferred')}
                  </div>
                  <div className="pie-container">
                    <h3 className="pie-title">Duplicate Workitems</h3>
                    {renderChart(DuplicatechartData, Bar, 'Duplicate Workitems')}
                  </div>
                  <div className="pie-container1">
                    <h3 className="pie-title">Top 10 Duplicate Work Items</h3>
                    {renderTopDuplicateWorkItemsChart(topDuplicateWorkItemsData, Pie, 'Top 10 Duplicate Work Items')}
                  </div>
                </div>
              )}
  
              {activeTab === 'Status' && (
                <div className="chart-container">
                  <div className="line-container">
                    <h3 className="pie-title">Unresolved WorkItems</h3>
                    {renderUnresolvedWorkItemsChart(unresolvedChartData, Line, 'Unresolved Workitems')}
                  </div>
                </div>
              )}
  
              {activeTab === 'Aging' && (
                <div className="chart-container">
                  <div className="age-container">
                    <h3 className="pie-title">Tickets by Aging</h3>
                    {renderAgeChart(AgechartData, Radar, 'Tickets by Aging')}
                  </div>
                  <div className="age-container">
                    <h3 className="pie-title">Work Items by Aging</h3>
                    {renderWorkitemAgeChart(WorkitemAgechartData, PolarArea, 'Work Items by Aging')}
                  </div>
                </div>
              )}
            </div>
        </div>
      ) : (
        <div className="AccDenied">Oops! You do not have permission to access Dashboard.</div>
      )}
    </>
  );
  
};