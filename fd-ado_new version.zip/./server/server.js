// let requestPack = require('request');
const request = require('request');
const Buffer = require('buffer').Buffer;
const axios = require('axios');
const _ = require('underscore');
// const { callback } = require('chart.js/helpers');

let det_str;

const $entity = $db.entity({ version: "v1" });
const transticEntity = $entity.get("AzureWorkItem");
//For error handling
const createPayload = $entity.get("createDBPayload");

exports = {
  events: [
    { event: 'onAppInstall', callback: 'onAppInstallCallback' },
    { event: 'onExternalEvent', callback: 'onExternalEventHandler' },
    { event: 'onScheduledEvent', callback: 'onScheduledEventHandler' },
    { event: 'onTicketUpdate', callback: 'onTicketUpdateHandler' },
    { event: 'onAppUninstall', callback: 'onAppUninstallHandler' },
    // { event: 'afterAppUpdate', callback: 'afterAppUpdateCallback'}
  ],
  onAppInstallCallback: async function (payload) {
    console.log("Logging arguments from onAppInstall event: " + JSON.stringify(payload));
    
    try {
      // Generate target URL
      const target_url = await generateTargetUrl();
      console.log("url", target_url);
  
      console.log("projects to update status:", payload.iparams.projects_status);
      const projs = payload.iparams.projects_status;
  
      if (projs && projs.length > 0) {
        // Set target_url and project IDs in the db
        try {
          const data = await $db.set("target_url", { target_url, ids: projs, previousData: payload.iparams });
          console.log("Set DB is successful", data);
        } catch (dbError) {
          logging(dbError); 
        }
  
        // project and update its status
        for (let i = 0; i < projs.length; i++) {
          console.log("Processing project:", projs[i]);
          try {
            await AzureStatusWeb(payload, projs[i], target_url);
          } catch (error) {
            if (error.response.message === "Access Denied") {
              renderData({ message: "Error: Azure DevOps Access Token Issue" }, false);
              return;
            }
          }
        }
      }
  
      // Create schedule
      await createSchedule();
      console.log("Schedule Created!");
  
      renderData(null, true); 
  
    } catch (error) {
      console.log("Error occurred:", error);
      renderData({ message: error.toString() }, false);
    }
  },  
  onExternalEventHandler: async function(args) 
  {   
	console.log("onexternal_event handler args",args);
    console.log("azure data***",JSON.stringify(args.data));
  const externalResponse = args.data.detailedMessage.html;
  console.log("externalResponse: ", externalResponse);
  const projectid = args.data.resourceContainers.project.id;
  console.log("projectid",projectid);
  const workItemType = args.data.detailedMessage.text.match(/^[\w\s]+(?=\s#\d+)/)[0].trim();
   console.log("workitem type",workItemType);
   const fetchstatedata = {
    projectId: projectid,     
    payload: workItemType, 
  }; 
  const {states} = await fetchworkitemstates(fetchstatedata);
  console.log("workitem category",states);
  const checkReplyOrNotes = externalResponse.includes("id=replyOrNotes");
  console.log("checkReplyOrNotes: ", checkReplyOrNotes);
  if(!checkReplyOrNotes){
    let str;
    // Finding Same domain name items
    const myString = args.data.detailedMessage.text;
    // let strr = args.data.detailedMessage.text;
    const n = myString.includes("transitioned");    
    const nn= myString.includes("commented");
    console.log("n , nn",n , nn);
    const myWord = "#";
    const myPattern = new RegExp('(\\w*'+myWord+'\\w*)','gi');

      const matches = myString.match(myPattern);  					 
      if(matches){
        str = matches[0].substring(1);											
				if(str==="undefined"){
          console.log("str is undefined");
				}else {														
					console.log(str,typeof(str));
				}}
      const Word = "Freshdesk: #";
      const Pattern = new RegExp('(\\w*'+Word+'\\w*)','gi');	
      const det =  args.data.detailedMessage.text.match(Pattern);
					console.log("Recently connected Ticket ID............",det);
          //All comment,Single comment
          const Word1 = "Freshdesk: #";
          const Pattern1 = new RegExp("(\\w*" + Word1 + "\\w*)", "gi");
          const det1 = args.data.detailedMessage.text.match(Pattern1);
    console.log("Comment through APP............", det1);
    if (det) {
      //New workItem add, connect
      //,, det_str = det[0].substring(12);
      det_str = det[0].substring(15);
      console.log("det_str............", det_str);
      console.log("det>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", det);
      webhookAddComment(args.data.detailedMessage.html, args.data.resourceContainers.project.id,str);
    } else if (det1) {
      //All comments via APP
      console.log("COMMENT ADDED THROUGH APP");
    } else {
      webhookAddComment(args.data.detailedMessage.html, args.data.resourceContainers.project.id,str);
    }	
    const workItemPattern = /#(\d+)/; 
    const workItemMatch = externalResponse.match(workItemPattern);
    const workItemID = workItemMatch ? workItemMatch[1] : null;
    console.log("Extracted WorkItem ID from workitem type:", workItemID);
      const record = await transticEntity.getAll(
        {
          query: {
            $and: [{
              workItem_id: String(workItemID)
            },
            {
              status: "Active"
           }]
        
         },
        }
      );
      console.log("rocord in onExternal EventHandler",JSON.stringify(record, null, 2));
      const activeRecords = record.records || [];
  console.log("Active Records with matching WorkItem ID:", activeRecords);
  
          const newStatePattern = /New State:\s*([\w\s]+)/;
          const newStateMatch = externalResponse.match(newStatePattern);
          const newState = newStateMatch ? newStateMatch[1] : null;
          console.log("Extracted New State:", newState);
  
          if (newState) {
              for (const activeRecord of activeRecords) {
                  console.log(`Updating activeRecord with WorkItem ID ${activeRecord.data.workItem_id} to new state: ${newState}`);
                  const categoryObject = states.find((item) => item.name === newState);
                  console.log("cateobj",states);
                  
                  const category = categoryObject ? categoryObject.category : null; // Default to null if no match found
              
                  console.log(`Matched Category for New State "${newState}":`, category);
                  const updatedData = {
                    ...activeRecord.data, 
                    workitem_status: newState, 
                    workitem_category: String(category)
                  };   
  
                  await transticEntity.update(activeRecord.display_id, updatedData);
  
                  const updatedRecord = await transticEntity.get(activeRecord.display_id);
                  console.log(`Updated Record for WorkItem ID ${activeRecord.data.workItem_id}:`, JSON.stringify(updatedRecord, null, 2));
              }
          } else {
              console.log("No new state found in the externalResponse.");
          }
    }else{
      console.log("It's a reply or notes from a Freshdesk");
    }	
  },
  onAppUninstallHandler: function (payload) {
    console.log(
      "Logging arguments from onAppUninstallHandler: ", payload
    );

    const deletingProjects = payload.iparams.projects_status;
    console.log("deletingProjects: ", deletingProjects);

    // Fetch target_url from the database
    $db.get("target_url").then(
      function (data) {
        if (data && data.target_url) {
          console.log("DB Data:", data);
          const target_url = data.target_url;
          console.log("Fetched URL from DB:", target_url);

          // ************************ Delete Webhook ************************
          if (deletingProjects && _.isArray(deletingProjects) && deletingProjects.length > 0) {
            console.log("projects to delete webhook...");
            getAllwebhook(deletingProjects, payload.iparams, target_url); 
          } else {
            console.log("no projects to delete webhook...");
          }

          console.log("deletingSchedule... ");
          deleteSchedule().then(
            () => {
              console.log("Schedule Deleted!.");
              renderData(null, true);
            },
            (err) => {
              console.log(err);
              renderData(false);
            }
          );
        } else {
          console.log("No target_url found in DB.");
          renderData(false);
        }
      },
      function (error) {
        console.error("Error fetching target_url from DB:", error);
        renderData(false);
      }
    );
  }, 
  onScheduledEventHandler: async function (args) {
    console.log("***onScheduledEventHandler***",args);
    
    try {
      const createdb = await createPayload.getAll({});
      const db_data = createdb.records;
      console.log("Get Retry data....", db_data);
      
      if (db_data && db_data.length > 0) {
        console.log("True//");
        // db_data = db_data.reverse(); 
        // Handle 7 elements
        for (let index = 0; index < Math.min(1, db_data.length); index++) {
          const element = db_data[index];
          
          if (element) {
            console.log("True//element", element.data.eventType,element);
            
            //event types
            if (element.data.eventType === "fetchAzureComment") {

              const res = await webhookAddComment(element.data.payload, element.data.projectId, element.data.workItemId);
                  console.log("res.........",res);
                  
                  try {
                    res && res === 200 ? await removeEventPayload(element.display_id): null;
                  } catch (error) {
                    console.log(error);
                  }

            } else if (element.data.eventType === "AddFreshdeskComment") {
      
                    const res = await processConvId(element.data.ticketId,element.data.payload);

                    console.log("res.........",res);
                    
                    try {
                      if (res && (res === 200 || res === 201)) {
                        await removeEventPayload(element.display_id);
                    }
                    } catch (error) {
                      console.log(error);
                    }
            }else if (element.data.eventType === "fetchWIstate") {
      
              const res = await fetchworkitemstates(element.data);

              console.log("res.........",res);
              
              try {
                res && res.status === 200 ? await removeEventPayload(element.display_id): null;
              } catch (error) {
                console.log(error);
              }}else if (element.data.eventType === "convFromReq") {
      
                const res = await getRequesterById(element.data.ticketId,element.data.workItemId,element.data.projectId,element.data.payload);
  
                console.log("res.........",res);
                
                try {
                  res && res === 200 ? await removeEventPayload(element.display_id): null;
                } catch (error) {
                  console.log(error);
                }
        }else if (element.data.eventType === "createAzureCmt") {
      
          const res = await createAzureComments(element.data.workItemId,element.data.projectId,element.data.payload);

          console.log("res.........",res);
          
          try {
            res && res === 200 ? await removeEventPayload(element.display_id): null;
          } catch (error) {
            console.log(error);
          }}else if (element.data.eventType === "convAttach") {
      
            const res = await convAttach(element.data.workItemId,element.data.projectId,element.data.payload);
  
            console.log("res.........",res);
            
            try {
              res && res === 200 ? await removeEventPayload(element.display_id): null;
            } catch (error) {
              console.log(error);
            }}
            else {
              console.log("Unhandled event type:", element.data.eventType);
            }
          }
        }
      }else{
        console.log("No Retry data");
      }
    } catch (error) {
      console.log("Error:", error);
    }
  },
  onTicketUpdateHandler: async function (args) {

    console.log("***onTicketUpdateCreateHandler***",args);

    if(args.data.ticket.changes&& Object.keys(args.data.ticket.changes).length !== 0 ){
      const changesArr = args.data.ticket.changes;
      console.log("changesArr.....",changesArr);
      try {
        console.log("tickt id",String(args.data.ticket.id));
        
        const response = await transticEntity.getAll({
          query: {
            $and: [
              { status: "Active" },
              { ticket_id: String(args.data.ticket.id)},
            ]
          }
        });
    
        const records = Array.isArray(response) ? response : response.records || [];
        console.log("records in onTicketUpdateHandler", JSON.stringify(records, null, 2));
    
        if (records.length > 0) {
            for (const record of records) {
              const updatedData = {
                    ticket_created_at: record.data.ticket_created_at,
                    created_at: record.data.created_at,
                    ticket_id: record.data.ticket_id,
                    ticket_status: changesArr.status ? String(changesArr.status[1]) : String(record.data.ticket_status),
                    workItem_id: record.data.workItem_id,
                    workitem_status: record.data.workitem_status,
                    status: record.data.status,
                    workitem_category: record.data.workitem_category
                };
    
                // Update the record in transticEntity
                await transticEntity.update(record.display_id, updatedData)
                console.log("Updated record:", JSON.stringify(updatedData, null, 2));
            }
        } else {
            console.log("No matching active record found for the specified ticket_id.");
        }
    } catch (err) {
        console.error("Error fetching records:", err);
    }
    
    }else{
      console.log("NO Updates");
    }
  },  
    afterAppUpdateCallback: function(payload) {
      console.log("Logging arguments from afterAppUpdate event: " + JSON.stringify(payload));
  
      $db.get("target_url").then(
        function (data) {
        if (data.ids) {
          console.log("db dataaa",data);
          const url = data.target_url;
          // let projs = args.keys;
          const projs = payload.iparams.projects_status;
          console.log("projs",projs);
          const currentData = payload.iparams;
          console.log("currentData",currentData);
    
          $db.update("target_url", "set", { "target_url": url, "ids": projs, "previousData": currentData }).then(
            function (data) {
              console.log("update db is success", data);
            },
            function (error) {
              // failure operation
              console.log("error...", error);
              logging(error);
            }
          );
          const db_data = data.previousData;
          console.log("db data",db_data);
          console.log("iparam data",currentData);
          
          const iparams_ids = projs;
          const db_ids = data.ids;
          console.log(" Iparams ids", iparams_ids);
          console.log(" DB ids ", db_ids);

          const ip_new = iparams_ids.filter((e) => !db_ids.includes(e));
          const db_absent = db_ids.filter((e) => !iparams_ids.includes(e));
          console.log(" db_absent ids", db_absent);
          console.log(" ip_new ids", ip_new);

          //delete webhook
          if(db_absent && _.isArray(db_absent) && db_absent.length > 0){
            const iparamsDataOne = payload.iparams
            console.log("iparamsDataOne",iparamsDataOne);

           getAllwebhookForPreviousDomain(projs, iparamsDataOne,url);
             
          }
          //add webhook
          const curren_AzureUrl = payload.iparams.azure_url;
          const curren_token = payload.iparams.azure_token;
          const previous_AzureUrl = data.previousData.azure_url;
          const previous_token = data.previousData.azure_token;
          console.log("curren_AzureUrl",curren_AzureUrl);
          console.log("curren_token",curren_token);
          console.log("previous_AzureUrl",previous_AzureUrl);
          console.log("previous_token",previous_token);
          
          if(curren_AzureUrl === previous_AzureUrl && curren_token === previous_token){

          console.log("Same url ",);
          console.log("ip_new",ip_new);

            if(ip_new && _.isArray(ip_new) && ip_new.length > 0){
            console.log(" ip_new ids", ip_new);
            for (let i = 0; i < ip_new.length; i++) {
              console.log("ip_new inside loop", ip_new[i]);
              const iparamsData = payload.iparams
              azureStatusAsync(iparamsData, ip_new[i], url)
              
              async function azureStatusAsync(currentData, proj_id, url) {
                try {
                  const status = await AzureStatusWebForPreviousDomain(currentData, proj_id, url);
                  console.log("status",status);
                } catch (error) {
                  console.error("Error occurred:", error);
                }
              }
            }
          }

          }else if (curren_AzureUrl !== previous_AzureUrl || curren_token !== previous_token){
            console.log("different url state");
      
            getAllwebhook(db_ids,db_data,url).then(() => {
              console.log(" ip_new ids", ip_new);
              const projs = payload.iparams.projects_status;
              console.log("projs",projs);
              if ((!projs || !_.isArray(projs) || projs.length === 0) && iparams_ids) {
                // ip_projsnew = iparams_ids;
                console.log("ip_new id in empty ip_new", projs);
              }
          
              if (projs && _.isArray(projs) && projs.length > 0) {
                console.log(" projs ids", projs);
          
                for (let i = 0; i < projs.length; i++) {
                  console.log("projs in diff url", projs[i]);
                  console.log("current data before azurestatusasync",currentData);
                  
                  azureStatusAsync(currentData, projs[i], url);
          
                  async function azureStatusAsync(currentData, proj_id, url) {
                    console.log("inside of azurestatusasync");
                    try {
                      const status = await AzureStatusWebForPreviousDomain(currentData, proj_id, url);
                      console.log("status", status);
                    } catch (error) {
                      console.error("Error occurred:", error); 
                    }
                  }
                }
              }
            }).catch((error) => { 
              console.error("Error in getAllwebhook:", error);
            });
          }
          
        }
      },
      function (error) {
        // failure operation
        // console.log("error", error);
        logging(error);
      }
    );
              renderData();
     
   },
  //   serverMethod: function (args) {
  //   console.log("*****serverMethod*****", args);
    
  //   $db.get("target_url").then(
  //       function (data) {
  //       if (data.ids) {
  //         console.log("db dataaa",data);
  //         const url = data.target_url;
  //         // let projs = args.keys;
  //         const projs = args.options.keys;
  //         console.log("projs",projs);
  //         const currentData = args.currentData;
  //         console.log("currentData",currentData);
    
  //         $db.update("target_url", "set", { "target_url": url, "ids": projs, "previousData": currentData }).then(
  //           function (data) {
  //             console.log("update db is success", data);
  //           },
  //           function (error) {
  //             // failure operation
  //             console.log("error...", error);
  //             logging(error);
  //           }
  //         );
  //         const db_data = data.previousData;
  //         console.log("db data",db_data);
  //         console.log("iparam data",currentData);
          
  //         const iparams_ids = projs;
  //         const db_ids = data.ids;
  //         console.log(" Iparams ids", iparams_ids);
  //         console.log(" DB ids ", db_ids);

  //         const ip_new = iparams_ids.filter((e) => !db_ids.includes(e));
  //         const db_absent = db_ids.filter((e) => !iparams_ids.includes(e));
  //         console.log(" db_absent ids", db_absent);
  //         console.log(" ip_new ids", ip_new);

  //         //delete webhook
  //         if(db_absent && _.isArray(db_absent) && db_absent.length > 0){
  //           const iparamsDataOne = args.iparams
  //           console.log("iparamsDataOne",iparamsDataOne);

  //          getAllwebhookForPreviousDomain(args.options.keys, iparamsDataOne);
             
  //         }
  //         //add webhook
  //         const url_state = args.azure_url_match
  //         console.log("url state",url_state);  
  //         console.log("args in add webhook state",args);  
  //         if(url_state === true){

  //         console.log("Same url ",);
  //         console.log("ip_new",ip_new);

  //           if(ip_new && _.isArray(ip_new) && ip_new.length > 0){
  //           console.log(" ip_new ids", ip_new);
  //           for (let i = 0; i < ip_new.length; i++) {
  //             console.log("ip_new inside loop", ip_new[i]);
  //             const iparamsData = args.iparams
  //             azureStatusAsync(iparamsData, ip_new[i], url)
              
  //             async function azureStatusAsync(currentData, proj_id, url) {
  //               try {
  //                 const status = await AzureStatusWebForPreviousDomain(currentData, proj_id, url);
  //                 console.log("status",status);
  //                     renderData(null, { "key": status }); 
  //               } catch (error) {
  //                 console.error("Error occurred:", error);
  //                  renderData(null,{"key": error});
  //               }
  //             }
  //           }
  //         }

  //         }else if (url_state === false) {
  //           console.log("different url state");
      
  //           getAllwebhook(db_ids,db_data).then(() => {
  //             console.log(" ip_new ids", ip_new);
  //             const projs = args.options.keys;
  //             console.log("projs",projs);
  //             if ((!projs || !_.isArray(projs) || projs.length === 0) && iparams_ids) {
  //               ip_projsnew = iparams_ids;
  //               console.log("ip_new id in empty ip_new", projs);
  //             }
          
  //             if (projs && _.isArray(projs) && projs.length > 0) {
  //               console.log(" projs ids", projs);
          
  //               for (let i = 0; i < projs.length; i++) {
  //                 console.log("projs in diff url", projs[i]);
  //                 console.log("current data before azurestatusasync",currentData);
                  
  //                 azureStatusAsync(currentData, projs[i], url);
          
  //                 async function azureStatusAsync(currentData, proj_id, url) {
  //                   console.log("inside of azurestatusasync");
  //                   try {
  //                     const status = await AzureStatusWebForPreviousDomain(currentData, proj_id, url);
  //                     console.log("status", status);
  //                     renderData(null, { "key": status }); 
  //                   } catch (error) {
  //                     renderData(null, { "key": error });
  //                     console.error("Error occurred:", error); 
  //                   }
  //                 }
  //               }
  //             }
  //           }).catch((error) => { 
  //             console.error("Error in getAllwebhook:", error);
  //           });
  //         }
          
  //       }
  //     },
  //     function (error) {
  //       // failure operation
  //       // console.log("error", error);
  //       logging(error);
  //     }
  //   );
  //   // renderData(null, { "key": "value" });
  // },
  
  GellALLComments: function (args) {


    return new Promise(async (resolve, reject) => {
      try {
        const data = await $request.invokeTemplate("getAzureComments", {
          context: {
            azure: args.azure,
            project: args.project,
            id: args.id,
          },
        });
        const parsedDetails = JSON.parse(data.response);
        resolve(parsedDetails);
      } catch (error) {
        console.error("error in GellALLComments", error);
        reject(error);
      }
    });
  },

  GetallAzureUsers:async function(args) {
    const data = await recursionFetch(args);
       console.log(data.length);
       
       renderData(null,data);
  },     
  authentication: async function (args) {    
    console.log("authentication args", args);
    // console.log("iparams: ", args.iparams);
    const attachmentUrls = await Addattach(args);
    for (let index = 0; index < attachmentUrls.length; index++) {
      const { url } = JSON.parse(attachmentUrls[index]);
      // console.log("attachmentUrls url:", url);
      const newattach = {
        op: "add",
        path: "/relations/-",
        value: {
          rel: "AttachedFile",
          url: url,
          attributes: {
            comment: "Spec for the task",
          },
        },
      };
      args.body_new.push(newattach);
    }
 
    try{
      const data = await $request.invokeTemplate("newWorkItemSubmit", {
                    context:{
                        "cus_project_id":args.cus["/fields/System.project_id"],
                        "cus_workItem_id":args.cus["/fields/System.workItem_id"]
                    }, 
                    body: JSON.stringify(args.body_new)
                })
              console.log("newWorkItemSubmit",JSON.parse(data.response));
              // console.log("newWorkItemSubmit",data);

              const azureRes = JSON.parse(data.response);
              console.log("azureRes: ", azureRes);
              // addTagTickets();

              if(data.status===200){
                // console.log(data);
                renderData(null, data);
              }
                }
                catch(err){
            
                  console.log(err);
                  // console.log(JSON.parse(err.response));
                  renderData(err, null);
                }
  },
  
  AddComments: async function (args) {
    const tag =
      "<div class='panel panel-warning' style='border-color: #faebcc;margin-bottom: 20px;background-color: #fff;border: 1px solid transparent;border-radius: 4px;-webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 5%);box-shadow: 0 1px 1px rgb(0 0 0 / 5%);font-size: 14px' data-identifyelement='352'>" +
      "<div class='panel-heading' style='color: rgb(0 0 0 / 90%);background-color: #c3d6b1d4;border-color: #faebcc;padding: 10px 15px;border-bottom: 1px solid transparent;border-top-left-radius: 3px;border-top-right-radius: 3px' data-identifyelement='353'>Comment from Freshdesk: #" +
      args.ticket_id +
      " </div>" +
      "<div class='panel-body' style='padding: 15px;background-color: #c3d6b129;' data-identifyelement='354'>" +
      "<strong data-identifyelement='355'>Freshdesk:&nbsp;</strong>&nbsp;" +
      "<a href='https://" +
      args.fd_domain +
      "/a/tickets/" +
      args.ticket_id +
      "' target='_blank' rel='noreferrer' heap-ignore='true' data-identifyelement='356'>#" +
      args.ticket_id +
      "</a>&nbsp;connected successfully." +
      "</div>" +
      '<div class="panel-footer" style="padding: 10px 15px;background-color: #c3d6b157;border-top: 1px solid rgb(200 200 200);border-bottom-right-radius: 3px;border-bottom-left-radius: 3px" data-identifyelement="357">' +
      'By: <em data-identifyelement="360">' +
      args.name +
      '"&lt;' +
      args.email +
      '&gt;"</em>' +
      "</div>" +
      "</div>";



    try {
      const response = await $request.invokeTemplate("postAddComments", {
        context: {
          url: args.url,
        },
        body: {
          text: tag,
        },
      });
      console.log("Response " + JSON.stringify(response.response));
    } catch (err) {
      console.error("Error " + JSON.stringify(err));
    }
  },
  addMultipleNotes: async function (args) {
    // let id = args.items_arr;


    const tag =
      "<div class='panel panel-warning' style='border-color: #faebcc;margin-bottom: 20px;background-color: #fff;border: 1px solid transparent;border-radius: 4px;-webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 5%);box-shadow: 0 1px 1px rgb(0 0 0 / 5%);font-size: 14px' data-identifyelement='352'>" +
      "<div class='panel-heading' style='color: rgb(0 0 0 / 90%);background-color: #c3d6b1d4;border-color: #faebcc;padding: 10px 15px;border-bottom: 1px solid transparent;border-top-left-radius: 3px;border-top-right-radius: 3px' data-identifyelement='353'>Comments from Freshdesk: #" +
      '<a href="https://' +
      args.fd_domain +
      "/a/tickets/" +
      args.ticket_id +
      '" target="_blank" rel="noreferrer" heap-ignore="true" data-identifyelement="358">' +
      args.ticket_id +
      "</a>" +
      " </div>" +
      "<div class='panel-body' style='padding: 15px' data-identifyelement='354'>" +
      args.notes +
      "</div>" +
      '<div class="panel-footer" style="padding: 10px 15px;background-color: #c3d6b157;border-top:  1px solid rgb(200 200 200);border-bottom-right-radius: 3px;border-bottom-left-radius: 3px" data-identifyelement="357">' +
      ' <div class="pull-right" style="float:right" data-identifyelement="359">By: <em data-identifyelement="360">' +
      args.name +
      '"&lt;' +
      args.email +
      '&gt;"</em>' +
      "</div>" +
      "</div>" +
      "</div>";



    try {
      const response = await $request.invokeTemplate("postMultipleNotes", {
        context: {
          project: args.project,
          items_arr: args.items_arr,
        },
        body: {
          text: tag,
        },
      });
      console.log("Response " + JSON.stringify(response.response));
    } catch (err) {
      console.error("Error " + JSON.stringify(err));
    }
  },
  onConversationCreateCallback: async function(args){

    console.log("conversation args", args);
    // console.log("conversation args", JSON.stringify(args.data));
    // console.log("conversation args", JSON.stringify(args.data.conversation));
    

    const selectedProjects = args.iparams.projects_status;
    // let wasAgent = args.data.actor.preferences.user_preferences.was_agent;
    const wasAgent = args.data.conversation.incoming;

// console.log(args.data);
// console.log("conv: ",args.data.conversation);
if(args.data.conversation.private === false){

  const ticketConversation = args.data.conversation;
// let ticketAttachments = args.data.conversation.attachments;
const workItemIdArray = []
const projectIdArray = []
let arrObjOne = []
let allConversations = []; 
let page = 1;               
let hasMorePages = true; 


try {
  while (hasMorePages) {
    const data = await $request.invokeTemplate("fetchConversation",{
    context:{
      "ticket_id": ticketConversation.ticket_id,
      "page": page,  
    }
  })
  // console.log("response: ", data.response);
  const parseResponse = JSON.parse(data.response);
  console.log("response: ", parseResponse);

  allConversations = [...allConversations, ...parseResponse];
  hasMorePages = parseResponse.length === 30;
  page++; 
}
  // allConversations.reverse();
  for (let i = 0; i < allConversations.length; i++) {
    const conversationBody = allConversations[i].body;
console.log("response: ", allConversations.length);
const b_text = allConversations[i].body_text;
const myString = b_text;
const stringifyConversationBody = JSON.stringify(conversationBody)
// console.log(stringifyConversationBody);
  

const firstHalf = stringifyConversationBody.indexOf("/_workitems/edit/") + 17;
const secondHalf = stringifyConversationBody.indexOf("\" target=");

const projectIdFirstHalf = stringifyConversationBody.indexOf("project_id_") + 11;
const projectIdSecondHalf = stringifyConversationBody.indexOf("\">Work Item:");
console.log("projectIdFirstHalf: ", projectIdFirstHalf, projectIdSecondHalf);

const projectId = stringifyConversationBody.slice(projectIdFirstHalf, projectIdSecondHalf-1)
console.log("projectId: ", projectId);

// console.log(stringifyConversationBody.slice(firstHalf, secondHalf-1));
const parseString = parseInt(stringifyConversationBody.slice(firstHalf, secondHalf-1))
// console.log(isNaN(parseString));

if(!isNaN(parseString)){
  // console.log(parseString);
  workItemIdArray.push(parseString)
  if(!projectId.includes("<", ">")){
    console.log("projectId: ", projectId);

    if (myString.includes("connected")) {
      console.log("connected",parseString);
      
      projectIdArray.push(projectId)
      const objOne = {
        work_item_id: parseString,
        project_id: projectId
      }
      arrObjOne.push(objOne);
    }
    if (myString.includes("unlinked")) {
      console.log("unlink",parseString);
      
      arrObjOne = arrObjOne.filter(e => e.work_item_id !== parseString);
    }

  }

}

  }

  console.log("object data:", arrObjOne.length);
  console.log("arrObjOne",arrObjOne);

  for (let j = 0; j < arrObjOne.length; j++) {
    console.log(`Processing object ${j + 1}:`, arrObjOne[j]);

    if (selectedProjects.includes(arrObjOne[j].project_id)) {
      console.log("Project is synchronized:", arrObjOne[j].project_id);

      console.log("Checking for active records...");
  
const convPayload = {
  conversation : ticketConversation,
  args : args
}
console.log("ticketConversation",ticketConversation);

        if (wasAgent === true) {
          console.log("Conversation is from the requester.");
          getRequesterById(
            ticketConversation.user_id,
            arrObjOne[j].work_item_id,
            arrObjOne[j].project_id,
            convPayload
          );
        } else {
          console.log("Conversation is from an agent.");
          getAgentById(
            ticketConversation.user_id,
            arrObjOne[j].work_item_id,
            arrObjOne[j].project_id,
            convPayload
          );
        }
 
    } else {
      console.log(
        `Project ${arrObjOne[j].project_id} is not synchronized. Skipping...`
      );
    }
  }

} catch (error) {
  console.log("conv error: ",error);
}
  }
  }
};

const getAgentById = async(agentId, workItem_id, project_id, convPayload) => {
  console.log("getAgentById payloads agentId, workItem_id, project_id, convPayload",agentId, workItem_id, project_id, convPayload);
  
  try{
    //  let simulateError = true; 

    //             if (simulateError) {
    //               throw { status: 429, message: "Rate limit exceeded" };
    //             }
    const data = await $request.invokeTemplate("fsAgents", {
      context:{
        "agent_id": agentId
      }
    })

    const parseResponse = JSON.parse(data.response);
    console.log("getAgentById Response",parseResponse);

    const convName = parseResponse.contact?.name;
    const convEmail = parseResponse.contact?.email;
    const agentPayload = {
      convName : convName,
      convEmail : convEmail,
      conversation : convPayload.conversation,
      args : convPayload.args
    }

    createAzureComments(workItem_id,project_id,agentPayload)
    return 200;
  }
  catch(error){
    console.log("getAgentById error: ", error);
    if(error.status && error.status === 429 ){
      retryTicket({
      eventType: "convFromReq", 
      workItemId: workItem_id,
      ticketId: agentId, 
      projectId: project_id,
      eventPayload: convPayload//args.data//Azure_detailedMessage//args.data.detailedMessage.html
    });
  }
  }
}
const getRequesterById = async(requesterId, workItem_id, project_id, convPayload) => {
  console.log("getRequesterById payloads requesterId, workItem_id, project_id, convPayload",requesterId, workItem_id, project_id, convPayload);

  try{
    const data = await $request.invokeTemplate("fsRequester", {
      context:{
        "requester_id": requesterId
      }
    })

    const parseResponse = JSON.parse(data.response);
    const convName = parseResponse.name;
    const convEmail = parseResponse.email;
    const agentPayload = {
      convName : convName,
      convEmail : convEmail,
      conversation : convPayload.conversation,
      args : convPayload.args
    }
    createAzureComments(workItem_id,project_id, agentPayload)
    // createAzureComments(arrObjOne[j].work_item_id, ticketConversation, arrObjOne[j].project_id, convName, convEmail)
    return 200;
  }
  catch(error){
    console.log("Error in getRequestedByID",error);
    if (error.status === 404) {
      console.log(`User ${requesterId} not found as a requester, checking agent...`);
      return getAgentById(requesterId, workItem_id, project_id, convPayload); // Call agent function
    }
    if(error.status && error.status === 429 ){
      retryTicket({
      eventType: "convFromReq", 
      workItemId: workItem_id,
      ticketId: requesterId, 
      projectId: project_id,
      eventPayload: convPayload//args.data//Azure_detailedMessage//args.data.detailedMessage.html
    });
  }

  }
}
const createAzureComments = async(workItem_id, project_id,agentPayload) => {
console.log("payload in azurecomment",agentPayload);

  const tag = "<div class='panel panel-warning' style='border-color: #faebcc;margin-bottom: 20px;background-color: #fff;border: 1px solid transparent;border-radius: 4px;-webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 5%);box-shadow: 0 1px 1px rgb(0 0 0 / 5%);font-size: 14px' data-identifyelement='352'>" +
  "<div class='panel-heading' style='color: rgb(0 0 0 / 90%);background-color: #c3d6b1d4;border-color: #faebcc;padding: 10px 15px;border-bottom: 1px solid transparent;border-top-left-radius: 3px;border-top-right-radius: 3px' data-identifyelement='353'>Comment from Freshdesk: #" + agentPayload.conversation.ticket_id + " </div>" +
  "<div class='panel-body' style='padding: 15px;' data-identifyelement='354'>" +
  "<strong data-identifyelement='355'>Freshdesk:&nbsp;</strong>&nbsp;" + agentPayload.conversation.body +"</div>" +
  '<div class="panel-footer" style="padding: 10px 15px;background-color: #c3d6b157;border-top: 1px solid rgb(200 200 200);border-bottom-right-radius: 3px;border-bottom-left-radius: 3px" data-identifyelement="357">' +
  'By: <em data-identifyelement="360">' + agentPayload.convName + '"&lt;' + agentPayload.convEmail + '&gt;"</em>' +
  "</div>" +
  "</div>";

  // let convBody = "<div type='hidden' id='replyOrNotes' name='replyOrNotes' value='3487'> " + conversation.body + " </div>"
  const convBody = "<div type='hidden' id='replyOrNotes' name='replyOrNotes' value='3487'> " + tag + " </div>";

try {
  const data = await $request.invokeTemplate("addMultipleNotes", {
context:{
  "modalData": workItem_id,
  "project": project_id
},
body:JSON.stringify({
  "text": convBody
})
  })
  console.log("createAzureComments response:", data);
  agentPayload.conversation.project_id = project_id;
  agentPayload.conversation.iparams = agentPayload.args.iparams;
  const attachmentUrls = await Addattach(agentPayload.conversation);
  convAttach(workItem_id, project_id, attachmentUrls)
  return 200;
} catch (error) {
  console.log("createAzureComments error: ", error);
  if(error.status && error.status === 429 ){
    retryTicket({
    eventType: "createAzureCmt", 
    workItemId: workItem_id,
    ticketId: null, 
    projectId: project_id,
    eventPayload: agentPayload
  });
}
}
}
const convAttach = async(workItem_id, project_id, attachmentUrls) => {
  console.log("payloads in convattach",workItem_id,project_id,attachmentUrls);
  
  const attachmentBody = []
  for (let index = 0; index < attachmentUrls.length; index++) {
    const { url } = JSON.parse(attachmentUrls[index]);
    const newattach = {
      op: "add",
      path: "/relations/-",
      value: {
        rel: "AttachedFile",
        url: url,
        attributes: {
          comment: "Spec for the task",
        },
      },
    };
    attachmentBody.push(newattach);
  }
try {
  const data = await $request.invokeTemplate("postattachments", {
context:{
  "work_item_id": workItem_id,
  "project_id": project_id
},
// body:JSON.stringify({
//   "text": conversation.body
// })
body: JSON.stringify(attachmentBody)
  })
  console.log("convAttach response:", data);
return 200;
} catch (error) {
  console.log("convAttach error: ", error);
  if(error.status && error.status === 429 ){
    retryTicket({
    eventType: "convAttach", 
    workItemId: workItem_id,
    ticketId: null, 
    projectId: project_id,
    eventPayload: attachmentUrls//args.data//Azure_detailedMessage//args.data.detailedMessage.html
  });
}
}
}
function getAllwebhook(projs,previousData,target_url) {
  console.log("getAllwebhook function starts...", projs,previousData);
  return new Promise(async function (resolve) {

    try {
      const response = await $request.invokeTemplate("previousGetAllAzureWebhook", {
        context:{
          azure_url_host: previousData.azure_url_host,
          azure_url_path: previousData.azure_url_path,
          azure_token: previousData.azuretoken
        }
      });
      // let body = JSON.stringify(response.response);
      const body = JSON.parse(response.response)
      // console.log("getAllAzureWebhook Response " + response.response);
      // console.log("getAllAzureWebhook body ", typeof body, body);

      // const projIdOne = projs

      console.log("proj in getAllWebhook",projs);

      // const datas = body;
        // console.log("datas", datas);
        const filtered_webhook = body.value.filter((webhook) =>
          projs.includes(webhook.publisherInputs.projectId) && webhook.consumerInputs.url === target_url
        );
        console.log(
          filtered_webhook.map((e) => e.publisherInputs.projectId),
          "FILTER WEBHOOKS in getALLWebhook"
        );
        if (filtered_webhook && _.isArray(filtered_webhook)) {
          for (let i = 0; i < filtered_webhook.length; i++) {
            try {
              if (filtered_webhook[i].id) {
                await deleteWebhookForPreviousDomain(filtered_webhook[i].id, previousData);
              } else {
                console.log("Skipping deletion, webhook ID not found:", filtered_webhook[i]);
              }
            } catch (error) {
              console.error("Error deleting webhook:", error);
            }
          }
        }
        resolve(true);
      // }
    } catch (err) {
      console.error("Error: " + err);
      console.error("Error details:", JSON.stringify(err, null, 2)); 
      // reject(err);
    }
  });
}

function getAllwebhookForPreviousDomain(projs, previousData,url) {
  console.log("getAllwebhookForPreviousDomain function starts...",projs,previousData,url);
  return new Promise(async function (resolve) {

    try {
      const response = await $request.invokeTemplate("previousGetAllAzureWebhook", {
        context:{
          azure_url_host: previousData.azure_url_host,
          azure_url_path: previousData.azure_url_path,
          azure_token: previousData.azuretoken
        }
      });
      // let body = JSON.stringify(response.response);
      const body = JSON.parse(response.response)
      const projIdOne = projs

      console.log("projIdOne: ", projIdOne);

      const datas = body;
      console.log("Full datas:", JSON.stringify(datas, null, 2));      
        // console.log("datas", datas);
        const filtered_webhook = body.value.filter((webhook) => 
          !projs.includes(webhook.publisherInputs.projectId) && webhook.consumerInputs.url === url
        );
      
        console.log(
          filtered_webhook.map((e) => e.publisherInputs.projectId),
          "FILTER WEBHOOKS"
        );
        if(filtered_webhook && _.isArray(filtered_webhook)){

        // if (filtered_webhook) {
          for (let i = 0; i < filtered_webhook.length; i++) {
            console.log("filtered_webhook in loop",filtered_webhook);
            
            try {
              const status = await deleteWebhookForPreviousDomain(filtered_webhook[i].id, previousData);
              console.log("Status of deletion:", status);
              // renderData(null, { "key": status }); 
            } catch (error) {
              console.error("Error during deletion:", error);
              // renderData(null,{"key": error});
            }
          }
        }
        resolve(true);
      // }
    } catch (err) {
      console.error("Error " + JSON.stringify(err));
      console.error("Error " + err);
      // reject(err);
    }
  });
}
function deleteWebhookForPreviousDomain(webhook_id, previousData) {
  return new Promise(async function (resolve, reject) {


    try {
      const response = await $request.invokeTemplate("previousDeleteAzureWebhook", {
        context: {
          webhook_id: webhook_id,
          azure_url_host: previousData.azure_url_host,
          azure_url_path: previousData.azure_url_path,
          azure_token: previousData.azuretoken
        },
      });
      console.log(
        "Respdelete webhook successfully " + response
      );
      console.log(JSON.stringify(response));
      console.log("Full datas:", JSON.stringify(response, null, 2));      
      
      resolve({ status: 200 });
    } catch (err) {
      console.error("Error in deleting webhook" + JSON.stringify(err));
      reject({ status: err.status});
    }
  });
}
function AzureStatusWebForPreviousDomain(currentData, proj_id, target_url) {
  console.log("AzureStatus........", currentData, proj_id, target_url);
  return new Promise(async function (resolve, reject) {
    const body = {
      publisherId: "tfs",
      resourceName: "workitem",
      eventType: "workitem.updated", //
      resourceVersion: "5.0",
      consumerId: "webHooks",
      consumerActionId: "httpRequest",
      scope: "all",
      publisherInputs: {
        projectId: proj_id,
      },
      consumerInputs: {
        //"url": "https://jinnss.freshdesk.com/priyadarshini0531",
        url: target_url,
      },
    };

    try {
      const response = await $request.invokeTemplate("previousPostAzureWebhook", {
        context:{
          azure_url_host: currentData.azure_url_host,
          azure_url_path: currentData.azure_url_path,
          azure_token: currentData.azuretoken
        },
        body: JSON.stringify(body),
      });
      console.log("webhook created for token", currentData.azuretoken ,"Project id", proj_id);
      console.log("Status webhook creation success", response);

      resolve({ status: 200 });
        } catch (err) {
      console.log("webhook creation failed", err);
      console.log("webhook creation failed status code", err.status);
      reject({ status: err.status});
      // reject(err);
    }
  });
}
async function webhookAddComment(Azure_detailedMessage, projectId, str) {
  console.log("***webhookAddComment***");
  console.log("azure detail message",Azure_detailedMessage);

  if (Azure_detailedMessage.includes("Freshdesk: #")) {
    console.log("inside of if it includes Freshdesk note");
    
    return;
    } 
  //console.log();
  let add_id;
  console.log("str--",str);

  try {
    const data = await $request.invokeTemplate("webhookComment", {
          context: {
              cus_workItem_id: str
          }
      });
      console.log("data----",data);
      
      const body = JSON.parse(data.response);
      if (body) {
        const conv = body.comments;
          console.log("conv", conv);
          const conv_id_status_array = [];
          
          // Filter for comments containing "Freshdesk: #"
      
          const n = conv.filter(e => e.text.includes("Freshdesk: #"));
          console.log("n.................", n.length);

          if (n && _.isArray(n) && n.length > 0) {
            console.log("TRUE");
            
              let conv_id = [];
              n.filter(findId);

              function findId(e) {    
                const myWord = "Freshdesk: #";
                const myPattern = new RegExp('(\\w*' + myWord + '\\w*)', 'gi');
                const matches = e.text.match(myPattern);

                  if (matches) {
                      console.log("matches............", matches);
                      const ind = matches[0].indexOf('#');
                      const str = matches[0].substring(ind + 1, matches[0].length);

                      // If the word is "undefined", skip it
                      if (str !== "undefined") {
                          let status = null;
                          const myString = e.text.toLowerCase();  

                          if (myString.includes("connected")) {
                              status = "connected";
                          }
                          if (myString.includes("unlinked")) {
                              status = "unlinked";
                          }

                          conv_id_status_array.push({ id: str, status: status });
                      }
                  }
                  return str;
              }

              console.log("conv_id_status_array: ", conv_id_status_array);
  
              for (let i = conv_id_status_array.length - 1; i >= 0; i--) {
                const item = conv_id_status_array[i];
          
                if (item.status === "connected") {
                    if (!conv_id.includes(item.id)) {
                        conv_id.push(item.id);
                        console.log("workitem added. Current conv_id", conv_id);
                    }
                } else if (item.status === "unlinked") {
                    conv_id = conv_id.filter(id => id !== item.id);
                    console.log("removed workitem id. Current conv_id", conv_id);
                }
            }
              console.log("updated Conv_id",conv_id);
              const conv_id_new = det_str ? conv_id.filter(e => e !== det_str) : conv_id;
              console.log("conv_id_new............", conv_id_new);

              // Loop through the filtered conv_id array and add notes for "connected" work items
              for (let i = 0; i < conv_id_new.length; i++) {
                  add_id = conv_id_new[i];

                  console.log("add_id...",add_id);
                  let shouldProcess = false;
                    // Check Comment              
                    if (Azure_detailedMessage.includes("Comment:")) {                   
                        console.log("Azure Comment: True");
                        shouldProcess = true;                    }

                    // Check status
                    const newStatePattern = /New State:\s*(\w+)/;
                    const newStateMatch = Azure_detailedMessage.match(newStatePattern);
                    const workItemState = newStateMatch ? newStateMatch[1].trim() : null;

                    if (workItemState) {
                        console.log("Extracted New State:", workItemState);
                        shouldProcess = true; 
                        
                        //const taskPattern = /(\w+)\s*#/;
                        const taskMatch =  Azure_detailedMessage.match(/<a [^>]*>([^#]+)#/);//Azure_detailedMessage.match(taskPattern);
                        const workItemType = taskMatch ? taskMatch[1].trim() : null;
                        console.log("workItemType---->",projectId,workItemType);
                    } 
                    if (shouldProcess) {
                      await processConvId(add_id, Azure_detailedMessage);
                  }     
              }
          }else{
            console.log("ELSE");            
          }
      } else {
          // Handle errors here if necessary
      }
      return 200;
  } catch (error) {
      console.log("webhook comment failed", error);
      
      if(error.status && error.status === 429 ){
        retryTicket({
        eventType: "fetchAzureComment", 
        workItemId: str,
        ticketId: null, 
        projectId: projectId,
        eventPayload: Azure_detailedMessage//args.data//Azure_detailedMessage//args.data.detailedMessage.html
      });
    }

     return error.status || 500;
  }

}

async function processConvId(add_id, Azure_detailedMessage) {
  console.log("add id inprocdf",add_id);
  
  try {
    const { responderId } = await getResponder(add_id, Azure_detailedMessage);
    if (responderId) {
      const {email} = await getResponderEmail(responderId,add_id,Azure_detailedMessage);
      await addPrivateNote(add_id, Azure_detailedMessage, email);
    } else {
      await addPrivateNote(add_id, Azure_detailedMessage);
    }
    return 200; 
  } catch (error) {
    console.error("Failed to processID:", error);
    if(error.status && error.status === 429 ){
    retryTicket({
      eventType: "AddFreshdeskComment",
      workItemId: null,
      ticketId: add_id,
      eventPayload: Azure_detailedMessage // args.data.detailedMessage.html
    });
  }
  return error.status || 500;
  }
}
async function getResponder(ticketId,Azure_detailedMessage) {
  console.log("ticid",ticketId);
  
  try {
    const response = await $request.invokeTemplate("getResponder", {
          context: {
              ticket_id: ticketId
          },
      });

      console.log("Fetched responder successfully", JSON.stringify(response));

      const responseStr = response.response;
      const responseObj = JSON.parse(responseStr);

      return {
        responderId: responseObj.responder_id,
        status: 200
    };
  }catch (error) {
    console.error("Failed to getRespondrd:", error);
    if(error.status && error.status === 429 ){
    retryTicket({
      eventType: "AddFreshdeskComment",
      workItemId: null,
      ticketId: ticketId,
      eventPayload: Azure_detailedMessage // args.data.detailedMessage.html
    });  
  }
  return error.status || 500;  }
}
async function getResponderEmail(responderID,add_id,Azure_detailedMessage) {
  console.log("responderID",responderID);
  
  try {
    const response = await $request.invokeTemplate("FreshdeskTicketAssignee", {
          context: {
            responder_id: responderID
          },
      });

      console.log("Successfully got responder details", response);
      const responseStr = response.response;
      const responseObj = JSON.parse(responseStr);
      const email = responseObj.contact.email;
      console.log("email",email);
      return {
        email: email || null,
        status: 200 
    }; 
  } catch (error) {
    console.error("Failed to getresponder email:", error);
    if(error.status && error.status === 429 ){
    retryTicket({
      eventType: "AddFreshdeskComment",
      workItemId: null,
      ticketId: add_id,
      eventPayload: Azure_detailedMessage // args.data.detailedMessage.html
    });  
  }
  return error.status || 500;
}
}
async function addPrivateNote(ticketId, noteContent, requester_mail = null) {
  // console.log("ticid",ticketId);
  // console.log("noteContent",noteContent);
  const noteData = {
    "body": noteContent
};

if (requester_mail) {
    noteData["notify_emails"] = [requester_mail];
}

  try {
    
      const dataTwo = await $request.invokeTemplate("freshdeskPrivateNotes", {
          context: {
              ticket_id: ticketId
          },
          body: JSON.stringify(noteData)
      });

      console.log("Note added successfully", dataTwo);
      return 200;
  } catch (error) {
    console.log("Create note failed: ", error);
    if(error.status && error.status === 429 ){
    retryTicket({
      eventType: "AddFreshdeskComment",
      workItemId: null,
      ticketId: ticketId,
      eventPayload: noteData // args.data.detailedMessage.html
    });  
  }
  return error.status || 500;  }
}
function storeAttachment(attachmentObj) {
  const { name, attachment_url, content_type, project_id, iparams } = attachmentObj;
  const bufferd = [];
  // console.log("attachment_url...",attachment_url);
  console.log("content_type...",content_type);

  return new Promise((resolve, reject) => {
    // Ensure `bufferd` is initialized properly
    request.get(attachment_url)
      .on('data', (data) => {
        // Pushing data into the buffer
        bufferd.push(data);
      })
      .on('error', (err) => {
        console.error("Error while fetching attachment:", err);
        reject(err); // Handle errors during data fetching
      })
      .on('complete',  () => {
        try {
          const buffer = Buffer.concat(bufferd);

          const host = iparams.azure_url;
          const fullURL = `https://${host}/${project_id}/_apis/wit/attachments?fileName=${name}&api-version=5.1`;

          console.log("fullURL...",fullURL);
          
          const options = {
            Authorization: iparams.azuretoken,
            'Content-Type': 'application/octet-stream'
          };

          // Making POST request to Azure to upload the attachment
          request.post(fullURL, {
            headers: options,
            body: buffer,
            encoding: null
          }, (error, response, body) => {
            if (error) {
              console.error('Error during upload:', error);
              return reject(error);
            }
            console.log('statusCode:', response && response.statusCode);

            // Handle 404 error
            if (response && response.statusCode === 404) {
              return reject(new Error("Attachment URL not found (404)"));
            }

            resolve(body); // Resolve the body when request succeeds
          });
        } catch (error) {
          console.error("Error during attachment processing:", error);
          reject(error); // Catch any errors during processing
        }
      });
  });
}

function Addattach(args) {

  
  const attach = args.attachments;
  // console.log("attach...",attach);
  
  return new Promise(async (resolve, reject) => {
    try {
      const attachmentPromises = [];

      for (let k = 0; k < attach.length; k++) {
        const { name, attachment_url, content_type } = attach[k];

        // Pushing promises without awaiting
        const attachmentPromise = await storeAttachment({ name, attachment_url, content_type, project_id: args.project_id, iparams: args.iparams });
        console.log("attachmentPromise;;;",attachmentPromise);
        
        attachmentPromises.push(attachmentPromise);
        console.log("attachmentPromises;;;;;;;;",attachmentPromises);
      }

      // Wait for all promises to resolve
      const attachmentRes = await Promise.all(attachmentPromises);
      resolve(attachmentRes); // Resolve all attachment responses
    } catch (err) {
      console.error("Error in Addattach:", err);
      reject(err); // Catch and reject errors in Addattach
    }
  });
}
function AzureStatusWeb(args, proj_id, target_url) {
  // console.log("AzureStatus........", args, proj_id, target_url);
  return new Promise(async function (resolve, reject) {

    const body = {
      publisherId: "tfs",
      resourceName: "workitem",
      eventType: "workitem.updated", //
      resourceVersion: "5.0",
      consumerId: "webHooks",
      consumerActionId: "httpRequest",
      scope: "all",
      publisherInputs: {
        projectId: proj_id,
      },
      consumerInputs: {
        //"url": "https://jinnss.freshdesk.com/priyadarshini0531",
        url: target_url,
      },
    };


    try {
      const response = await $request.invokeTemplate("postAzureWebhook", {
        body: JSON.stringify(body),
      });
      // console.log("Response " + JSON.stringify(response.response));
      console.log("Status webhook creation success", response);

      resolve(true);
    }catch (err) {
      // console.error("Error " + JSON.stringify(err));
      console.log("webhook creation failed", err);
      if (err.status === 403) {
        reject(new Error("Access Denied"));
      } else {
        reject(err);
      }    }
  });
}
function recursionFetch(args,token = null, member = []) {
	console.log("recursionFetch...........");
  return new Promise((resolve)=>{
    // let url = "https://vsaex.dev.azure.com/flashmobilevending/_apis/userentitlements?api-version=7.1-preview.3&$orderBy=name asc"
    let url = `https://vssps.${args.azure}/_apis/graph/users?api-version=6.0-preview.1`;
    if(token){
      url = url + `&continuationToken=${token}`
    }
    const options =  {
        url: url,
        method: "GET",
        headers: {
           'Authorization':args['iparams'].azuretoken,//'Basic OnR2cW0zYjQzN3dkdTdibXJ6dG1lanEzeTUyeXlkNG96eW9vbWx2NHVybG5kZHFoZmR2d3E=',//args['iparams'].azuretoken,
        'content-Type':'application/json-patch+json'
        }
      };
console.log("options...",options);
    request(options,function (error, response, body) {
	if(body)
       {    
			//console.log("body...",body);
			console.log("error...",error);
			const { value} = JSON.parse(body);
			// console.log(member);
			member = [...member, ...value];
			//member = member.concat(value);  
			// console.log(members.map(e=> e.user.displayName));
			if(response.headers['x-ms-continuationtoken']){
        resolve(recursionFetch(args,response.headers['x-ms-continuationtoken']));
			}else{
        resolve(member);
			}}else{
        resolve(member);}
      }
    );
  })
}

async function retryTicket(payload) {
  console.log("Retry Ticket - " + payload.eventType,payload.ticketId,payload.eventPayload);

  try {
      const res = await addTicket(payload);
      console.log("Retry Ticket Response - " + res);
  } catch (error) {
      console.error("Error in retryTicket: ", error);
  }
}

function removeEventPayload(id) {
  console.log("***removeEventPayload***",id);
  return createPayload.delete(id);
}

async function addTicket(payload) {
  console.log("addTicket...",payload);
  
  try {
    const createPayloaddb = await createPayload.getAll({});
    console.log("createPayloaddb----",createPayloaddb);
    
    if (createPayloaddb.records.length > 0) {
      const auth_table = createPayloaddb.records;
      // console.log("auth_table--->",auth_table);

      console.log("auth_table--->", payload.ticketId, payload.workItemId, typeof payload.workItemId, payload.eventType);

      // To avoid duplicates
      const findDub = auth_table.findIndex((e) => {
        console.log("Checking:", {
          ticketIdInTable: e.data.ticketId,
          workItemIdInTable: e.data.workItemId,
          eventTypeInTable: e.data.eventType,
          ticketIdInPayload: payload.ticketId,
          workItemIdInPayload: payload.workItemId,
          eventTypeInPayload: payload.eventType
        });
      
        return (
          (e.data.ticketId === payload.ticketId || e.data.workItemId === payload.workItemId) &&
          e.data.eventType === payload.eventType
        );
      });
      
      console.log("findDub----->", findDub);
      

      if (findDub === -1) {
        
        try {
          payload.eventType ? await setEventPayload(payload) : null;
        } catch (error) {
          console.log(error);
        }
      }else{
        console.log("Record already exist");        
        sameEvent = true;
      }
    } else {
      console.log("No records found in entity. So, Add record");      
      try {
        payload.eventType ? await setEventPayload(payload) : null;
      } catch (error) {
        console.log(error);
      }
    }
  } catch (error) {
    try {
      payload.eventType ? await setEventPayload(payload) : null;
    } catch (error) {
      console.log(error);
    }
  }
  return payload.ticketId;
}
function setEventPayload(payload) {
  console.log("append ticket createPayload",payload);
  try{
    const a = createPayload.create({
      workItemId: payload.workItemId ? payload.workItemId.toString():"",
      ticketId: payload.ticketId ? payload.ticketId.toString():"",
      payload: payload.eventPayload,
      projectId: payload.projectId,
      eventType: payload.eventType
    });
    console.log("aaaaa",a);
    
  }catch (error) {
    console.error("Error in retryTicket: ", error);
  }

}
// let isErrorSimulated = false; 
async function fetchworkitemstates(payload) {
  console.log("payload in fetchworkitemstate",payload)
 console.log("proj & workitem type",payload.projectId,payload.payload);
 
  try {
   
    const stateData = await $request.invokeTemplate("getAzureStateList", {
      context: {
        project_id: payload.projectId,
        workItem_Type: payload.payload
      }
    });

    const stateList = JSON.parse(stateData.response);
    console.log("State Data Response:", stateData);

    if (stateList.count === 0) {
      console.log("No states found. Check project ID and work item type.");
    }

    return { status: 200, states: stateList.value };
  } catch (error) {
    console.log("Error in fetchWorkItemStates:", error);
    if(error.status && error.status === 429 ){
      retryTicket({
      eventType: "fetchWIstate", 
      workItemId: null,
      ticketId: null, 
      projectId: payload.projectId,
      eventPayload: payload.payload//args.data//Azure_detailedMessage//args.data.detailedMessage.html
    });
  }
  return error.status || 500;  }
}

function createSchedule() {
  return $schedule.create({
    name: "ticket_reminder",
    data: {
      ticket_id: 10001,
    },
    schedule_at: "2018-06-10T07:00:00.860Z",
    repeat: {
      time_unit: "minutes",
      frequency: 1,
    },
  });
}

function deleteSchedule() {
  return $schedule.delete({
    name: "ticket_reminder",
  });
}
function logging(error){
	console.log(error);
}
